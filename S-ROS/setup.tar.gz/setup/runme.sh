## 1st Time Config

#!/bin/bash

# Interface name
INTERFACE1="enp1s0"
INTERFACE2="enp7s0"
INTERFACE3="enp8s0"

# Static IP configuration
IP_ADDRESS="192.168.122.11"
NETMASK="255.255.255.0"
GATEWAY="192.168.122.1"
DNS_NAMESERVERS="8.8.8.8 8.8.4.4"

# Check if the script is run as root
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root."
  exit 1
fi

# Create a backup of the interfaces file
cp /etc/network/interfaces /etc/network/interfaces.bak

# Configure the interface
cat << EOF > /etc/network/interfaces

source /etc/network/interfaces.d/*

# The loopback network interface
auto lo
iface lo inet loopback

# Configuration for $INTERFACE1
auto $INTERFACE1 
iface $INTERFACE inet static
    address $IP_ADDRESS
    netmask $NETMASK
    gateway $GATEWAY
    dns-nameservers $DNS_NAMESERVERS

# Configuration for $INTERFACE2 
auto $INTERFACE2  
iface $INTERFACE2 inet manual 

# Configuration for $INTERFACE3
auto $INTERFACE33
iface $INTERFACE3 inet manual 

EOF

# Restart networking
systemctl restart networking

echo "Static IP configuration applied to $INTERFACE."
echo "IP Address: $IP_ADDRESS"
echo "Netmask: $NETMASK"
echo "Gateway: $GATEWAY"
echo "DNS Nameservers: $DNS_NAMESERVERS"

# Update system
apt update && apt upgrade -y

# Install required packages
apt install -y net-tools traceroute tcpdump rsync snmp rsyslog vlan bridge-utils fail2ban \
              iptables iptables-persistent frr frr-pythontools wondershaper wireguard \
              pacemaker corosync pcs cockpit #ansible

# Enable IP Forwarding
echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
sysctl -p

# Enable and start Cockpit
systemctl enable --now cockpit.socket

# Enable and start Fail2Ban
#systemctl enable fail2ban
#systemctl start fail2ban

# Configure motd
cp motd /etc/motd
cp bashrc /root/.bashrc
cat fstab >> /etc/fstab  

echo "Initial setup completed. Please configure FRR, WireGuard, and Pacemaker manually."

systemctl daemon-reload

sudo cp -a /etc/* /setup/etc-backup/
sudo cp -a /var/* /setup/var-backup/


cp setup-tmpfs.service /etc/systemd/system/setup-tmpfs.service
systemctl enable setup-tmpfs.service


mkdir -p /usr/share/images/grub/
cp -r bg.png /usr/share/images/grub/grub.png

rm /etc/issue.d/cockpit.issue

cp logo-2.png /usr/share/pixmaps/debian-logo.png
cp bg.png /usr/share/cockpit/branding/default/bg-plain.jpg 


echo "sysadmin  ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers" 
 
systemctl stop openhpid
systemctl disable  openhpid
apt remove openhpid
systemctl disable fail2ban

