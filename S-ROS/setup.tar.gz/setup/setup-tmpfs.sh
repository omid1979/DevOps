#!/bin/bash
mount -t tmpfs tmpfs /etc
mount -t tmpfs tmpfs /var
cp -a /setup/etc-backup/* /etc/
cp -a /setup/var-backup/* /var/

